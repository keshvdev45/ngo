
import json, os, subprocess, sys, platform, shlex
from pathlib import Path
from typing import Optional, Dict, Any, List

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

BASE_DIR = Path(__file__).parent.resolve()
DATA_ACTIONS = BASE_DIR / "ai_actions.json"
DATA_SKILLS = BASE_DIR / "skills.json"
PUBLIC_DIR = BASE_DIR

app = FastAPI(title="Max AI Server", version="1.0.0")

# Serve static files (index.html, script.js, style.css)
app.mount("/static", StaticFiles(directory=str(PUBLIC_DIR)), name="static")

def load_json(path: Path) -> Dict[str, Any]:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}

def save_json(path: Path, data: Dict[str, Any]):
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")

class QueryIn(BaseModel):
    prompt: str
    mode: Optional[str] = "default"

class ActionResult(BaseModel):
    ok: bool
    message: str
    data: Optional[Dict[str, Any]] = None

# Very simple "AI" brain placeholder with rule-based commands and a stub LLM hook.
def brain_response(prompt: str, skills: Dict[str, Any]) -> str:
    p = prompt.strip().lower()
    # A few direct skills
    if p in skills.get("commands", {}):
        return f"Executing command: {p}"
    # Simple Q/A fallback
    if "open " in p and p.replace("open ","") in skills.get("commands", {}):
        return f"Executing command: {p}"
    return f"I heard: '{prompt}'. I'm ready to act based on your skills.json and actions."

def execute_command(cmd: str) -> str:
    try:
        # Cross-platform basic execution
        if platform.system() == "Windows":
            completed = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        else:
            completed = subprocess.run(shlex.split(cmd), capture_output=True, text=True)
        out = completed.stdout.strip() or completed.stderr.strip() or "(no output)"
        return out[:10000]  # limit output
    except Exception as e:
        return f"Error: {e}"

@app.get("/", response_class=HTMLResponse)
async def root():
    # Serve index.html
    index = PUBLIC_DIR / "index.html"
    return HTMLResponse(index.read_text(encoding="utf-8"))

@app.get("/api/skills")
async def get_skills():
    return load_json(DATA_SKILLS)

@app.get("/api/actions")
async def get_actions():
    return load_json(DATA_ACTIONS)

@app.post("/api/query")
async def post_query(body: QueryIn):
    skills = load_json(DATA_SKILLS)
    actions = load_json(DATA_ACTIONS)
    text = brain_response(body.prompt, skills)

    # Attempt action execution if the text indicates execution
    executed: List[Dict[str, Any]] = []
    cmd_map: Dict[str, str] = skills.get("commands", {})
    key = body.prompt.strip().lower()
    if key in cmd_map:
        cmd = cmd_map[key]
        output = execute_command(cmd)
        executed.append({"command": cmd, "output": output})

    return {"response": text, "executed": executed}

@app.post("/api/skills/update")
async def update_skills(payload: Dict[str, Any]):
    data = load_json(DATA_SKILLS)
    data.update(payload or {})
    save_json(DATA_SKILLS, data)
    return {"ok": True}

@app.post("/api/actions/update")
async def update_actions(payload: Dict[str, Any]):
    data = load_json(DATA_ACTIONS)
    data.update(payload or {})
    save_json(DATA_ACTIONS, data)
    return {"ok": True}
