from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), "controllers"))
import control
import controller
import controller_brain
import dev_action_controller
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

app = Flask(__name__, static_folder=BASE_DIR)
CORS(app)

# Serve index.html
@app.route('/')
def index():
    return send_from_directory(BASE_DIR, 'index.html')

# Serve JS/CSS
@app.route('/<path:filename>')
def static_files(filename):
    return send_from_directory(BASE_DIR, filename)

# API endpoint to run AI/control actions
@app.route('/api/action', methods=['POST'])
def ai_action():
    data = request.json
    action = data.get("action")
    params = data.get("params", {})

    try:
        # Route actions to the correct control script
        if action == "run_ai_query":
            prompt = params.get("prompt", "")
            # Call your brain AI function (from controller_brain.py)
            response = controller_brain.ask_ai(prompt)
            return jsonify({"status": "ok", "response": response})

        elif action == "run_control":
            script = params.get("script")
            args = params.get("args", "")
            # Map script names to imported modules
            scripts_map = {
                "control.py": control,
                "controller.py": controller,
                "controller_brain.py": controller_brain,
                "dev_action_controller.py": dev_action_controller
            }
            module = scripts_map.get(script)
            if module and hasattr(module, "main"):
                result = module.main(args)
                return jsonify({"status": "ok", "result": result})
            else:
                return jsonify({"status": "error", "msg": "Script not found or no main() function"})

        elif action == "run_cmd":
            import subprocess
            cmd = params.get("cmd")
            result = subprocess.getoutput(cmd)
            return jsonify({"status": "ok", "result": result})

        elif action == "open_app":
            import subprocess
            app_name = params.get("app")
            args = params.get("args", "")
            if os.name == 'nt':
                subprocess.Popen(f'start {app_name} {args}', shell=True)
            return jsonify({"status":"ok","msg":f"Opening {app_name}"})

        else:
            return jsonify({"status":"error","msg":"Unknown action"})

    except Exception as e:
        return jsonify({"status":"error","msg":str(e)})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
