import requests
import os
import webbrowser
import json
import sys
import time
import shutil

# =============== Typing Effect ===============
def type_out(text, color="green"):
    colors = {
        "green": "\033[92m",
        "cyan": "\033[96m",
        "yellow": "\033[93m",
        "magenta": "\033[95m",
        "red": "\033[91m",
        "reset": "\033[0m"
    }
    sys.stdout.write(colors.get(color, ""))
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(0.01)  # typing speed
    sys.stdout.write(colors["reset"] + "\n")

# =============== AI Query Function ===============
def ask_ai(prompt):
    r = requests.post("http://127.0.0.1:11434/api/generate",
        json={
            "model": "devabhaiya/dev:trained",
            "prompt": f"User asked: {prompt}\nAlways respond with ACTION: <command>"
        }, stream=True)
    
    output = ""
    for line in r.iter_lines():
        if line:
            try:
                data = json.loads(line.decode("utf-8"))
                if "response" in data:
                    output += data["response"]
            except:
                pass
    return output.strip()

# =============== Action Executor ===============
def execute_action(task, response):
    if response.startswith("ACTION:"):
        command = response.replace("ACTION:", "").strip()

        # 🔥 Normalize the response (remove backticks, quotes, weird prefixes)
        command = command.replace("`", "").replace('"', "").replace("'", "")

        type_out(f"⚡ Executing cleaned command: {command}", "magenta")
        cmd = command.lower()

        # ---- Predefined Actions ----
        if "chrome" in cmd:
            os.system("cmd /c start chrome")

        elif "explorer" in cmd:
            os.system("cmd /c start explorer")

        elif "settings" in cmd:
            os.system("cmd /c start ms-settings:")

        elif "youtube" in cmd and "search" in cmd:
            query = task.replace("youtube search", "").strip()
            webbrowser.open(f"https://www.youtube.com/results?search_query={query}")

        elif "youtube" in cmd:
            webbrowser.open("https://www.youtube.com")

        elif "google" in cmd and "search" in cmd:
            query = task.replace("google search", "").strip()
            webbrowser.open(f"https://www.google.com/search?q={query.replace(' ', '+')}")

        elif "network scan" in cmd:
            os.system("cmd /c netsh wlan show networks")

        elif "task manager" in cmd:
            os.system("cmd /c taskmgr")

        elif "notepad" in cmd:
            os.system("cmd /c notepad")

        elif "calculator" in cmd or "calc" in cmd:
            os.system("cmd /c calc")

        elif "command prompt" in cmd or cmd == "cmd":
            os.system("start cmd")

        elif "powershell" in cmd:
            os.system("start powershell")

        elif "control panel" in cmd:
            os.system("cmd /c control")

        elif "microsoft edge" in cmd:
            os.system("cmd /c start msedge")

        elif "firefox" in cmd:
            os.system("cmd /c start firefox")

        elif "visual studio code" in cmd or "vscode" in cmd:
            os.system("cmd /c code")

        elif "word" in cmd:
            os.system("cmd /c start winword")

        elif "excel" in cmd:
            os.system("cmd /c start excel")

        else:
            # 🚀 Fallback: try running it as Windows command
            os.system(f"cmd /c {command}")

    else:
        type_out("🤖 AI gave text (not action):", "yellow")
        print(response)

# =============== Loop ===============
if __name__ == "__main__":
    columns = shutil.get_terminal_size().columns
    banner = "🚀 Dev Brain Controller [AI Agent Mode] started (type 'exit' to quit)"
    print("\033[92m" + banner.center(columns) + "\033[0m\n")
    
    while True:
        user_input = input("\033[96m>>> \033[0m")
        if user_input.lower() in ["exit", "quit"]:
            break
        response = ask_ai(user_input)
        type_out(f"\n🤖 AI: {response}\n", "green")
        execute_action(user_input, response)
def main(args=None):
    print(f"[CONTROLLER] Running with args: {args}")
    return f"[CONTROLLER] Done {args}"
