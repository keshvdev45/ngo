import json
import requests
import streamlit as st

OLLAMA_URL = "http://127.0.0.1:11434"

st.set_page_config(page_title="Ollama Chat UI", page_icon="🤖", layout="wide")
st.title("🤖 Ollama – Custom Chat UI")

with st.sidebar:
    st.subheader("Settings")
    # fetch models
    try:
        models_resp = requests.get(f"{OLLAMA_URL}/api/tags", timeout=5).json()
        model_names = [m["name"] for m in models_resp.get("models", [])] or ["llama3"]
    except Exception:
        model_names = ["llama3"]

    model = st.selectbox("Model", model_names, index=0)
    temperature = st.slider("Temperature", 0.0, 1.5, 0.7, 0.1)
    system_prompt = st.text_area("System Prompt (optional)", value="", height=120,
                                 placeholder="You are a helpful assistant…")
    max_tokens = st.number_input("Max Tokens (0 = unlimited)", min_value=0, value=0, step=50)
    keep_history = st.toggle("Keep conversation context", value=True)
    st.markdown("---")
    st.caption("Tip: Press ⏎ to send, Shift+⏎ for newline.")

# session state
if "messages" not in st.session_state:
    st.session_state.messages = []

# render history
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

# input
prompt = st.chat_input("Type your message…")

def stream_ollama_chat(model, prompt, temperature, system_prompt, max_tokens, history):
    """
    Stream from Ollama /api/chat with JSONL responses.
    """
    payload = {
        "model": model,
        "stream": True,
        "options": {"temperature": temperature} if temperature is not None else {},
        "messages": [],
    }

    if system_prompt.strip():
        payload["messages"].append({"role": "system", "content": system_prompt})

    if keep_history and history:
        payload["messages"].extend(history)

    payload["messages"].append({"role": "user", "content": prompt})

    with requests.post(f"{OLLAMA_URL}/api/chat", json=payload, stream=True) as r:
        r.raise_for_status()
        full_text = ""
        for line in r.iter_lines(decode_unicode=True):
            if not line:
                continue
            try:
                data = json.loads(line)
            except json.JSONDecodeError:
                continue

            # new token chunk
            if "message" in data and "content" in data["message"]:
                token = data["message"]["content"]
                full_text += token
                yield token

            # stop condition (optional info)
            if data.get("done"):
                break
        return

if prompt:
    # show user message
    with st.chat_message("user"):
        st.markdown(prompt)
    st.session_state.messages.append({"role": "user", "content": prompt})

    # get assistant streaming
    with st.chat_message("assistant"):
        placeholder = st.empty()
        streamed = ""
        try:
            for token in stream_ollama_chat(
                model=model,
                prompt=prompt,
                temperature=temperature,
                system_prompt=system_prompt,
                max_tokens=max_tokens,
                history=[m for m in st.session_state.messages if m["role"] in ("system","user","assistant")]
            ):
                streamed += token
                placeholder.markdown(streamed)
        except requests.RequestException as e:
            placeholder.error(f"⚠️ Request error: {e}")
            streamed = ""

    # push assistant message
    st.session_state.messages.append({"role": "assistant", "content": streamed})

# clear history button
col1, col2 = st.columns ([1,1])

# inside assistant message area, after 'streamed' is ready:
import urllib.parse as up
if streamed and streamed.lower().startswith("open youtube and search"):
    q = streamed.split("search",1)[-1].strip()
    st.markdown(f"[Open YouTube for **{q}**](https://www.youtube.com/results?search_query={up.quote_plus(q)})")