import requests
import os
import webbrowser
import json
import sys
import time
import shutil
import os
import webbrowser


if __name__ == "__main__":
    prompt = sys.argv[1] if len(sys.argv) > 1 else ""
    # Here you can call your local AI model
    print(f"AI brain received prompt: {prompt}")

def execute_command(command, query=None):
    try:
        if command == "open chrome":
            os.system("start chrome")
        
        elif command == "google search":
            if query:
                webbrowser.open(f"https://www.google.com/search?q={query}")
            else:
                webbrowser.open("https://www.google.com")

        elif command == "open explorer":
            os.system("explorer")

        elif command == "open youtube":
            webbrowser.open("https://www.youtube.com")

        elif command == "youtube search":
            if query:
                webbrowser.open(f"https://www.youtube.com/results?search_query={query}")
            else:
                webbrowser.open("https://www.youtube.com")

        else:
            print(f"❌ Unknown command: {command}")
    except Exception as e:
        print(f"⚠️ Error executing {command}: {str(e)}")

# =============== Load Skills ===============
def load_skills():
    try:
        with open("skills.json", "r") as f:
            return json.load(f)
    except Exception as e:
        print(f"⚠️ Failed to load skills.json: {e}")
        return {}

# =============== Typing Effect ===============
def type_out(text, color="green"):
    colors = {
        "green": "\033[92m",
        "cyan": "\033[96m",
        "yellow": "\033[93m",
        "magenta": "\033[95m",
        "red": "\033[91m",
        "reset": "\033[0m"
    }
    sys.stdout.write(colors.get(color, ""))
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(0.01)  # typing speed
    sys.stdout.write(colors["reset"] + "\n")

# =============== AI Query Function ===============
def ask_ai(prompt):
    r = requests.post("http://127.0.0.1:11434/api/generate",
        json={"model": "devabhaiya/dev:trained", "prompt": f"Task: {prompt}\nRespond with ACTION or TEXT"},
        stream=True)
    
    output = ""
    for line in r.iter_lines():
        if line:
            try:
                data = json.loads(line.decode("utf-8"))
                if "response" in data:
                    output += data["response"]
            except:
                pass
    return output.strip()

# =============== Action Executor ===============
def execute_action(task, response, skills):
    lower_resp = response.lower()

    # --- If AI gives explicit ACTION ---
    if response.startswith("ACTION:"):
        command = response.replace("ACTION:", "").strip()
        type_out(f"⚡ Executing: {command}", "magenta")

        # 1. Match with skills.json
        for key, value in skills.items():
            if key in command.lower():
                if value.startswith("http"):  # open website
                    webbrowser.open(value)
                elif value == "google":  # google search
                    query = task.replace("google search", "").strip()
                    url = f"https://www.google.com/search?q={query.replace(' ', '+')}"
                    webbrowser.open(url)
                elif value == "youtube":  # youtube search
                    query = task.replace("youtube search", "").strip()
                    url = f"https://www.youtube.com/results?search_query={query.replace(' ', '+')}"
                    webbrowser.open(url)
                else:  # system command
                    os.system(value)
                return

        # If no skill matched, try raw execution
        os.system(command)

    # --- Built-in Action Detection ---
    elif "youtube" in lower_resp and "search" in lower_resp:
        query = task.replace("youtube search", "").replace("open youtube and search", "").strip()
        url = f"https://www.youtube.com/results?search_query={query.replace(' ', '+')}"
        webbrowser.open(url)
        type_out(f"🎬 Opening YouTube for: {query}", "cyan")

    elif "google" in lower_resp and "search" in lower_resp:
        query = task.replace("google search", "").strip()
        url = f"https://www.google.com/search?q={query.replace(' ', '+')}"
        webbrowser.open(url)
        type_out(f"🌍 Searching Google for: {query}", "cyan")

    elif "[run]" in lower_resp:
        cmd = response.split("[RUN]")[-1].strip()
        os.system(cmd)
        type_out(f"⚡ Ran command: {cmd}", "magenta")

    else:
        type_out("🤖 AI Response (No Action):", "yellow")
        print(response)

# =============== Main Loop ===============
if __name__ == "__main__":
    columns = shutil.get_terminal_size().columns
    banner = "🚀 Dev Brain Controller [Ultimate AI Agent Mode] (type 'exit' to quit)"
    print("\033[92m" + banner.center(columns) + "\033[0m\n")

    skills = load_skills()

    while True:
        user_input = input("\033[96m>>> \033[0m")
        if user_input.lower() in ["exit", "quit"]:
            type_out("👋 Exiting Dev Brain Controller...", "red")
            break
        response = ask_ai(user_input)
        type_out(f"\n🤖 AI: {response}\n", "green")
        execute_action(user_input, response, skills)
def ask_ai(prompt):
    # Replace this with your AI query logic
    print(f"[BRAIN] Received prompt: {prompt}")
    response = f"AI Response for: {prompt}"
    return response

def main(args=None):
    return ask_ai(args)
