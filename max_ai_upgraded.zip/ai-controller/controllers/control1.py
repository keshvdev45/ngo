import os
import sys
import time
import subprocess
import json
import pyautogui  # pip install pyautogui

# ===== Typing Effect =====
def type_out(text, color="green"):
    colors = {
        "green": "\033[92m",
        "cyan": "\033[96m",
        "yellow": "\033[93m",
        "magenta": "\033[95m",
        "red": "\033[91m",
        "reset": "\033[0m"
    }
    sys.stdout.write(colors.get(color, ""))
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(0.01)
    sys.stdout.write(colors["reset"] + "\n")

# ===== Predefined Safe Commands =====
COMMANDS = {
    "chrome": 'start "" "chrome"',
    "msedge": 'start "" "msedge"',
    "explorer": 'start explorer',
    "settings": 'start ms-settings:',
    "notepad": 'start notepad',
    "calculator": 'start calc',
    "cmd": 'start cmd',
    "powershell": 'start powershell',
    "youtube": 'start "" "https://www.youtube.com"',
    "google": lambda query: f'start "" "https://www.google.com/search?q={query}"'
}

# ===== Execute Structured JSON Actions =====
def execute_json_action(action_json):
    try:
        action_data = json.loads(action_json)
    except json.JSONDecodeError:
        type_out(f"❌ Invalid JSON: {action_json}", "red")
        return

    action_type = action_data.get("action")
    params = action_data.get("params", {})

    if action_type == "open_app":
        app = params.get("app")
        args = params.get("args", "")
        if app in COMMANDS:
            cmd = f'{COMMANDS[app]} {args}'.strip()
            type_out(f"⚡ Opening app: {cmd}", "magenta")
            os.system(cmd)
        else:
            type_out(f"❌ Unknown app: {app}", "red")

    elif action_type == "gui":
        sequence = params.get("sequence", [])
        for step in sequence:
            if step["type"] == "press":
                pyautogui.press(step["key"])
                type_out(f"⚡ Pressed key: {step['key']}", "cyan")
            elif step["type"] == "type":
                pyautogui.typewrite(step["text"])
                type_out(f"⚡ Typed text: {step['text']}", "cyan")
            time.sleep(0.1)

    elif action_type == "scan_net":
        target = params.get("target")
        options = params.get("options", "")
        cmd = f"ping -n 1 {target.split('/')[0]}"  # simple ping for demo
        type_out(f"⚡ Scanning network: {cmd}", "magenta")
        os.system(cmd)

    elif action_type == "run_cmd":
        cmd = params.get("cmd")
        if cmd:
            type_out(f"⚡ Running command: {cmd}", "magenta")
            os.system(cmd)
        else:
            type_out("❌ No command specified", "red")

    else:
        type_out(f"❌ Unknown action type: {action_type}", "red")

# ===== Main Loop =====
if __name__ == "__main__":
    type_out("🚀 Ultimate AI Controller with JSON Actions started (type 'exit' to quit)", "cyan")
    while True:
        user_input = input("\033[96m>>> \033[0m")
        if user_input.lower() in ["exit", "quit"]:
            break
        # If input looks like JSON
        if user_input.strip().startswith("{"):
            execute_json_action(user_input)
        else:
            # Fallback to old plain commands
            ai_output = input("AI Output: ")
            # (reuse your previous execute_action function if needed)
            # execute_action(user_input, ai_output)
