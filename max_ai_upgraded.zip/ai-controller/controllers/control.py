import json
import os
import subprocess
from dev_action_controller import execute_json_action  # import your function from dev_action_controller

# ===== Load JSON Config =====
CONFIG_PATH = "c:/Users/bhaiy/.ollama/ai_actions.json"

with open(CONFIG_PATH, "r") as f:
    config = json.load(f)

files = config.get("files", {})
default_actions = config.get("actions", [])

# ===== Launch other Python files =====
def launch_file(file_key):
    path = files.get(file_key)
    if path:
        print(f"🚀 Launching {file_key}: {path}")
        subprocess.Popen(["python", path], shell=True)
    else:
        print(f"❌ File not found for key: {file_key}")

# ===== Execute default actions from JSON =====
def execute_defaults():
    for action in default_actions:
        execute_json_action(json.dumps(action))

# ===== Main CLI =====
if __name__ == "__main__":
    print("🎛️  Unified AI Controller Started (type 'exit' to quit)")
    while True:
        cmd = input(">>> ")
        if cmd.lower() in ["exit", "quit"]:
            break
        elif cmd.startswith("launch "):
            _, file_key = cmd.split(maxsplit=1)
            launch_file(file_key)
        elif cmd.startswith("{"):
            execute_json_action(cmd)
        elif cmd.lower() == "defaults":
            execute_defaults()
        else:
            print("❌ Unknown command. Use JSON, 'launch <file>', or 'defaults'.")
def main(args=None):
    # Example: just print args or run some logic
    print(f"[CONTROL] Received args: {args}")
    return f"[CONTROL] Executed with args: {args}"
