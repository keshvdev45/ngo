import sys
import subprocess

if __name__ == "__main__":
    # get arguments from server
    args = sys.argv[1:]  # [app_name, app_args]
    app_name = args[0]
    app_args = args[1] if len(args) > 1 else ""
    
    try:
        subprocess.Popen(f'start {app_name} {app_args}', shell=True)
        print(f"Opened {app_name} {app_args}")
    except Exception as e:
        print(f"Error: {e}")
