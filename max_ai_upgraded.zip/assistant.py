import requests, os, webbrowser, json, sys, time, shutil, pyautogui, socket, platform, subprocess
import speech_recognition as sr
import pyttsx3

# ---------------- Voice Engine ----------------
engine = pyttsx3.init()
def speak(text):
    engine.say(text)
    engine.runAndWait()

# ---------------- Typing Effect ----------------
def type_out(text, color="green"):
    colors = {
        "green": "\033[92m", "cyan": "\033[96m", "yellow": "\033[93m",
        "magenta": "\033[95m", "red": "\033[91m", "reset": "\033[0m"
    }
    sys.stdout.write(colors.get(color, ""))
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(0.01)
    sys.stdout.write(colors["reset"] + "\n")

# ---------------- Load Skills ----------------
def load_skills():
    try:
        with open("skills.json", "r") as f:
            return json.load(f)
    except:
        return {}

# ---------------- AI Query ----------------
def ask_ai(prompt):
    r = requests.post("http://127.0.0.1:11434/api/generate",
        json={"model": "devabhaiya/dev:trained",
              "prompt": f"User said: {prompt}\nRespond strictly as: ACTION: <command>"},
        stream=True)
    output = ""
    for line in r.iter_lines():
        if line:
            try:
                data = json.loads(line.decode("utf-8"))
                if "response" in data:
                    output += data["response"]
            except:
                pass
    return output.strip()

# ---------------- System Info ----------------
def system_info():
    info = f"""
    OS: {platform.system()} {platform.release()}
    Node: {platform.node()}
    Version: {platform.version()}
    Machine: {platform.machine()}
    IP: {socket.gethostbyname(socket.gethostname())}
    """
    return info

# ---------------- Execute Action ----------------
def execute_action(task, response, skills):
    if response.startswith("ACTION:"):
        command = response.replace("ACTION:", "").strip().lower()
        type_out(f"⚡ Executing: {command}", "magenta")
        speak(f"Executing {command}")

        # Skills.json lookup
        for key, value in skills.items():
            if key in command:
                if value.startswith("http"):
                    webbrowser.open(value)
                elif value == "google":
                    query = task.replace("google search", "").strip()
                    url = f"https://www.google.com/search?q={query.replace(' ', '+')}"
                    webbrowser.open(url)
                else:
                    os.system(value)
                return

        # Extra actions
        if "scroll down" in command: pyautogui.scroll(-500)
        elif "scroll up" in command: pyautogui.scroll(500)
        elif "move mouse" in command: pyautogui.moveTo(500, 500, duration=1)
        elif "click" in command: pyautogui.click()
        elif "type" in command: pyautogui.typewrite(task.replace("type", "").strip())
        elif "lock" in command: os.system("rundll32.exe user32.dll,LockWorkStation")
        elif "shutdown" in command: os.system("shutdown /s /t 1")
        elif "restart" in command: os.system("shutdown /r /t 1")
        elif "ip config" in command: os.system("ipconfig")
        elif "network scan" in command: os.system("netsh wlan show networks")
        elif "system info" in command: print(system_info()); speak("System information displayed")
        else: os.system(command)

    else:
        type_out("🤖 AI: " + response, "yellow")
        speak(response)

# ---------------- Voice Input ----------------
def listen():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("🎤 Listening...")
        r.pause_threshold = 1
        audio = r.listen(source)
    try:
        query = r.recognize_google(audio, language='en-in')
        print(f"👤 You said: {query}")
        return query
    except:
        return ""

# ---------------- Main Loop ----------------
if __name__ == "__main__":
    columns = shutil.get_terminal_size().columns
    banner = "🤖 Dev Personal Assistant v1 [AI + System Core]"
    print("\033[92m" + banner.center(columns) + "\033[0m\n")

    skills = load_skills()

    while True:
        choice = input("🎙️ Type or say [t/v]: ").lower()
        if choice == "t":
            user_input = input(">>> ")
        else:
            user_input = listen()

        if user_input in ["exit", "quit", "bye"]:
            speak("Goodbye! Shutting down.")
            break

        response = ask_ai(user_input)
        type_out(f"\n🤖 AI: {response}\n", "green")
        execute_action(user_input, response, skills)
