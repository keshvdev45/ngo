
const chatBox = document.getElementById('chat-box');
const input = document.getElementById('user-input');
const sendBtn = document.getElementById('send-btn');
const micBtn = document.getElementById('mic-btn');
const statusText = document.getElementById('status-text');
const skillsView = document.getElementById('skills-view');

function addLine(text, who="system") {
  const div = document.createElement('div');
  div.className = who;
  div.textContent = text;
  chatBox.appendChild(div);
  chatBox.scrollTop = chatBox.scrollHeight;
}

async function loadSkills() {
  try {
    const res = await fetch('/api/skills');
    const data = await res.json();
    skillsView.textContent = JSON.stringify(data, null, 2);
  } catch(e) {
    skillsView.textContent = "Failed to load skills.json";
  }
}

async function sendCommand() {
  const v = input.value.trim();
  if (!v) return;
  addLine("You: " + v, "you");
  input.value = "";
  statusText.textContent = "Thinking...";

  const res = await fetch('/api/query', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({prompt: v})
  });
  const data = await res.json();
  addLine("AI: " + data.response, "ai");

  if (data.executed && data.executed.length) {
    data.executed.forEach(exe => {
      addLine("Executed: " + exe.command, "exec");
      addLine(exe.output, "output");
    });
  }
  statusText.textContent = "Ready.";
}

sendBtn.onclick = sendCommand;
input.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') sendCommand();
});

// Voice via browser (if supported)
let recognition = null;
if ('webkitSpeechRecognition' in window) {
  recognition = new webkitSpeechRecognition();
  recognition.lang = 'en-US';
  recognition.onstart = () => statusText.textContent = "Listening...";
  recognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript;
    input.value = transcript;
    statusText.textContent = "Heard: " + transcript;
    sendCommand();
  };
  recognition.onend = () => statusText.textContent = "Ready.";
}

micBtn.onclick = () => {
  if (recognition) recognition.start();
  else alert("Speech recognition not supported in this browser.");
};

// init
loadSkills();
