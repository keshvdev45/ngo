import tkinter as tk
import threading
import os
import json
import webbrowser
import requests
import speech_recognition as sr
import pyttsx3

# ---------- AI + Skills ----------
def load_skills():
    try:
        with open("skills.json", "r") as f:
            return json.load(f)
    except:
        return {}

skills = load_skills()

engine = pyttsx3.init()
engine.setProperty("rate", 170)

def speak(text):
    engine.say(text)
    engine.runAndWait()

def listen():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        r.pause_threshold = 1
        audio = r.listen(source)
    try:
        query = r.recognize_google(audio, language="en-in")
        return query.lower()
    except:
        return ""

def ask_ai(prompt):
    try:
        r = requests.post("http://127.0.0.1:11434/api/generate",
            json={"model": "devabhaiya/dev:trained", "prompt": prompt},
            stream=True)
        output = ""
        for line in r.iter_lines():
            if line:
                data = json.loads(line.decode("utf-8"))
                if "response" in data:
                    output += data["response"]
        return output.strip()
    except:
        return "⚠️ AI not responding."

def execute_action(task, response):
    for key, value in skills.items():
        if key in task:
            if value.startswith("http"):
                webbrowser.open(value)
            elif value == "google":
                query = task.replace("google search", "").strip()
                webbrowser.open(f"https://www.google.com/search?q={query}")
            else:
                os.system(value)
            return
    os.system(response)

# ---------- GUI ----------
class AssistantUI:
    def __init__(self, root):
        self.root = root
        self.root.title("🧠 Dev Personal Assistant")
        self.root.geometry("600x400")
        self.root.config(bg="black")

        self.chat_box = tk.Text(root, bg="black", fg="lime", font=("Consolas", 12))
        self.chat_box.pack(pady=10, fill="both", expand=True)

        self.entry = tk.Entry(root, bg="gray15", fg="white", font=("Consolas", 12))
        self.entry.pack(fill="x", pady=5)
        self.entry.bind("<Return>", self.handle_text)

        tk.Button(root, text="🎤 Speak", command=self.handle_voice, bg="green", fg="white").pack()

    def handle_text(self, event=None):
        query = self.entry.get()
        self.entry.delete(0, tk.END)
        self.process_query(query)

    def handle_voice(self):
        threading.Thread(target=self.listen_voice).start()

    def listen_voice(self):
        self.chat_box.insert(tk.END, "\n🎤 Listening...\n")
        query = listen()
        if query:
            self.chat_box.insert(tk.END, f">>> You: {query}\n")
            self.process_query(query)

    def process_query(self, query):
        self.chat_box.insert(tk.END, f"\n>>> You: {query}\n")
        response = ask_ai(query)
        self.chat_box.insert(tk.END, f"🤖 AI: {response}\n")
        speak(response)
        execute_action(query, response)

# ---------- Main ----------
if __name__ == "__main__":
    root = tk.Tk()
    ui = AssistantUI(root)
    speak("Hello Boss, your personal assistant is ready.")
    root.mainloop()
