import os
import sys
import time
import subprocess
import webbrowser

# ===== Typing Effect =====
def type_out(text, color="green"):
    colors = {
        "green": "\033[92m",
        "cyan": "\033[96m",
        "yellow": "\033[93m",
        "magenta": "\033[95m",
        "red": "\033[91m",
        "reset": "\033[0m"
    }
    sys.stdout.write(colors.get(color, ""))
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(0.01)
    sys.stdout.write(colors["reset"] + "\n")

# ===== Predefined Safe Commands =====
COMMANDS = {
    "chrome": 'start "" "chrome"',
    "msedge": 'start "" "msedge"',
    "explorer": 'start explorer',
    "settings": 'start ms-settings:',
    "notepad": 'start notepad',
    "calculator": 'start calc',
    "cmd": 'start cmd',
    "powershell": 'start powershell',
    "youtube": 'start "" "https://www.youtube.com"',
    "google": lambda query: f'start "" "https://www.google.com/search?q={query}"'
}

# ===== Clean AI Response =====
def clean_response(response: str) -> str:
    cleaned = response.replace("ACTION:", "").replace("`", "").replace("'", "").replace('"', "").strip().lower()
    # Remove prefixes like ruti, run, rdp, markdown syntax
    for prefix in ["ruti -c", "run ", "rdp /device", "```"]:
        if cleaned.startswith(prefix):
            cleaned = cleaned.replace(prefix, "").strip()
    return cleaned

# ===== Execute Command =====
def execute_action(task_input: str, ai_output: str):
    command = clean_response(ai_output)

    # Google search handling
    if "google search" in task_input.lower():
        query = task_input.lower().replace("google search", "").strip()
        cmd = COMMANDS["google"](query)
        type_out(f"⚡ Executing: {cmd}", "magenta")
        os.system(cmd)
        return

    # URL handling
    if command.startswith("http"):
        type_out(f"⚡ Opening URL: {command}", "magenta")
        os.system(f'start "" "{command}"')
        return

    # Map command to dictionary
    if command in COMMANDS:
        cmd = COMMANDS[command]
        if callable(cmd):
            cmd = cmd("")  # fallback for lambda
        type_out(f"⚡ Executing: {cmd}", "magenta")
        os.system(cmd)
    else:
        # Attempt to execute Python scripts if path ends with .py
        if command.endswith(".py") and os.path.exists(command):
            type_out(f"⚡ Running Python script: {command}", "magenta")
            subprocess.run([sys.executable, command])
        else:
            type_out(f"❌ Unknown or unsupported command: {command}", "red")

# ===== Main Loop =====
if __name__ == "__main__":
    type_out("🚀 Ultimate AI Controller started (type 'exit' to quit)", "cyan")
    while True:
        user_input = input("\033[96m>>> \033[0m")
        if user_input.lower() in ["exit", "quit"]:
            break
        ai_output = input("AI Output: ")
        execute_action(user_input, ai_output)
