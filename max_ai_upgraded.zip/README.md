
# Max AI — Upgraded

Local web UI + Python backend.

## Run

```bash
cd "/mnt/data/heres_ai_project/heres"
python -m pip install -r requirements.txt
uvicorn server:app --host 0.0.0.0 --port 7860 --reload
```

Then open http://localhost:7860 in your browser.

## Files
- `server.py` — FastAPI backend, serves static and `/api/*`.
- `index.html`, `script.js`, `style.css` — Frontend (served from `/static`).
- `skills.json` — Command map. Add entries under `commands` to execute system commands.
- `ai_actions.json` — Reserved for future action pipelines.

## Notes
- Command execution uses `skills.json`. Example:

```json
{
  "commands": {
    "open notepad": "notepad",
    "whoami": "whoami"
  }
}
```

Type: `whoami` in the UI, the server will execute and return output.
